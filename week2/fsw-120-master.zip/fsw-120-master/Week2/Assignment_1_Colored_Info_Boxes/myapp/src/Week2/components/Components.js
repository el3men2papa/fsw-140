import React from "react"
import Title from "./Title"
import Information from "./Information"
import Subtitle from "./Subtitle"

function Components(){
    return(
        <div>
            <h2><Title /></h2>
            <h2><Subtitle /></h2>
            <h2><Information /></h2>
        </div>
    )
}

export default Components