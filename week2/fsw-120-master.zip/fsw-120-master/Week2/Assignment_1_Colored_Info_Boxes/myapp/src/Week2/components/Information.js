import React from "react"
import "./Information.css"

function Information(){
    return (
        <h2 className = " informationCss "> Information </h2>
    )
}

export default Information