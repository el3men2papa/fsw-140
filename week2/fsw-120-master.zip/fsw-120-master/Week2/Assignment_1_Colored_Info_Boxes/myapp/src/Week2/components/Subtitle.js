import React from "react"
import "./Subtitle.css"

function Subtitle(){
    return (
<h2 className = "SubtitleCss"> Subtitle</h2>
    )
}

export default Subtitle


