import React from "react"
import "./Title.css"

function Title(){
    return(
        <h2 className = "tittleCss">Title</h2>
    )
}


export default Title